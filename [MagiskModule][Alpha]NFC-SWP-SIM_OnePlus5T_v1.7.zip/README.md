# Oneplus 5T NFC SWP sim enabler
## Description
Updated version of shakalaca'ss module
NOT WORKING FOR NOW STILL WIP!!  
## Requirements
* NFC-SIM
* Oneplus 5T
* Magisk 17+
* Oxygen OS Pie 9.0.4+
## Changelog
- v1.3 Change lib
- v1.2 Add lib
- v1 First test release
## Version Status
* Alpha
